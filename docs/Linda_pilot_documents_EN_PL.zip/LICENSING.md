# Linda licensing in one page

Linda was formerly named Linda-Pro; it includes the detectors Linda Assay (formerly Linda-Pro) and Linda Loupe (formerly Linda-Pro Lite). Licences bought under the old name stay valid.

Linda is one product that you can get in two ways. The rules are the same for both.

| | What you get | Where from |
|---|---|---|
| **Windows app** | installer with a window, colour map, automatic model updates | `Linda-Setup.exe` on [GitHub Releases](https://github.com/Lendarixon/Linda/releases/latest) |
| **Command line / Python** | the `linda_pro` package and tools (`python -m linda_pro`, `evaluate.py`) | [GitHub](https://github.com/Lendarixon/Linda) |
| **Models and calibration** | the neural networks and thresholds (about 2.9 GB) | [Hugging Face](https://huggingface.co/Lindarixon/Linda-Pro); the app downloads them for you |

## 1. Free: personal, non-commercial use

The app, the command-line tools, the code, the models and the calibration are **free** for personal, non-commercial use under **CC BY-NC 4.0**.
This covers, for example: checking your own or your friends' texts for yourself, studying, hobby projects, non-commercial research and learning how the detector works.
Download them from Hugging Face or GitHub, or let the app do it. No registration, no key, no limits.

## 2. Commercial licence: what you buy

You buy a **licence to use the software commercially**. One licence covers **everything together**: the app (interface), the command-line tools and package, and the models and calibration.
You do not buy the models separately, and the interface is not licensed separately from the models.

Commercial use means using Linda for paid work or for clients, inside a company, school, university or other organization's operations (for example staff checking submitted work), in a product or service you sell, or any other use that earns money or supports an organization's business.

| Licence | Price | Who | Devices | Updates |
|---|---|---|---|---|
| **Personal** | $10, one-off | one person (freelancer, consultant, small business owner) | up to 3 | fixes for the purchased version; new features may need a separate licence |
| **Team** | $30, one-off | up to 10 people | up to 20 | fixes for the purchased version; new features may need a separate licence |
| **Organization / University** | $500 per year | one organization at one site | up to 200 | for the whole licence year, including new model versions |

* **How you get it.** After payment you receive a licence key by e-mail. Enter it in the app (Licence dialog): the licence notice disappears. The command-line tools do not check keys; the licence applies to them in the same way, and the key is your proof of purchase.
* **Version rule.** A Personal or Team key is perpetual: the version you bought and its fixes keep working. New features and new models may be released only under separate licences or as a paid upgrade. The Organization licence is valid for the paid year and includes all updates released in that year; when it ends, commercial use of Linda under it ends unless renewed.
* **Nothing is locked.** The app works the same without a key; the key is the legal permission, not a technical switch.
* **Not included in these licences:** exclusive rights, OEM / white-label integration into another product, hosting Linda as a service or API for third parties, redistribution of the models, custom calibration on your texts. These are agreed individually: write to lindapro.support@proton.me with your use case, volume and deployment.

## 3. Quick questions

* **Do I pay for the models?** Not for personal non-commercial use. For commercial use the licence in section 2 covers the models.
* **I use only the command line at work. Do I need a key?** Yes, commercial use needs a licence however you run the software.
* **I am a student or a teacher checking my own work or studying the tool.** Free (non-commercial). A school or university running checks as part of its operations needs the Organization licence.
* **I am a freelancer checking texts for clients.** Personal licence.
* **How are devices counted? Can I move my key to a new computer?** A purchased key is activated on the computer where you enter it (the app sends the key and an anonymous machine id, never your texts) and counts against the device limit of your licence. Copying the app or its licence file to another computer does not carry the licence over. To move: open the Licence window and press Remove key while online (this frees the slot after a successful server request), then enter the key on the new computer. If the old computer is gone, write to the support address and the slot is freed.
* **Can I put it into my product or a website?** Only under a separate OEM agreement.
* **What does the app send over the internet?** Only model downloads, update checks and, when you enter a key, the key, activation identifiers, a random device label and a machine-derived identifier hash. Your texts never leave your computer. See [Privacy](privacy.html).
* **What if I disagree with a result?** The detector gives a probabilistic estimate and can be wrong; it must not be the sole basis for decisions about people. See [Terms](terms.html).

This page summarizes the licence. The legal texts are the [Terms](terms.html), the file `LICENSE` (CC BY-NC 4.0 and the commercial licence) and `COMMERCIAL_LICENSE.md` in the repositories; this page is not legal advice.

## Tax, payment and renewal

The prices are USD 10 (Personal, one payment), USD 30 (Team, one payment) and USD 500 per year (Organization / University). Polar is the Merchant of Record. The organization tax setting was checked on 11 October 2026 and is **Location based**. For a Polish consumer checkout the displayed tax is included: Personal total USD 10 (tax USD 1.87), Team total USD 30 (tax USD 5.61), Organization USD 500/year (tax USD 93.50). These are observations for Poland, not a guarantee of identical tax treatment everywhere. The final amount, tax and billing interval are shown before payment; business VAT treatment depends on the billing information and applicable rules. No tax settings or prices were changed for this document.

Personal and Team are one-time purchases. Organization is an annual **automatically renewing subscription** in the current Polar checkout. Cancel renewal in the customer portal before the next billing date; commercial permission continues to the end of the paid year. This is separate from the free 14-day commercial evaluation from first launch, which has no billing or automatic conversion.

## Refunds

Existing published policy, preserved: for Personal/Team, if Linda does not work for you, contact lindapro.support@proton.me within 14 days of purchase for a full refund through Polar. For Organization, within 14 days a refund is offered if the key has not been used for commercial work or a technical issue cannot be fixed. After that, renewal can be cancelled; the unused part of the paid year is not voluntarily refunded. Mandatory consumer rights are not reduced by this summary. Polar can process refunds under its own policies. This document is a vendor summary and has not been reviewed by a lawyer.

## Free 14-day commercial evaluation

Individuals and organizations may evaluate Linda for commercial use free of charge for 14 calendar days from their first launch of the application. No registration, separately agreed start date, paid key, payment card or subscription is required. This is a licence permission, not an app timer or technical lock; the user is responsible for observing the period. Reinstallation, an update or switching devices does not restart the period for the same person or organization. The trial is for internal evaluation, without resale, redistribution, third-party hosting or adverse decisions about people. After the period, continued commercial use requires the appropriate paid licence. Personal non-commercial use remains free under CC BY-NC 4.0 without a 14-day limit. There is no automatic charge, renewal or conversion to a paid subscription. Texts remain with the user; sharing aggregate feedback is optional.
